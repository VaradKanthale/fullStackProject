package spring_web2.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;

import org.h2.mvstore.Page;
import org.hibernate.grammars.hql.HqlParser.LocalDateTimeLiteralContext;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import spring_web2.Entity.Customer;
import spring_web2.Exception.ResourceNotFoundException;
import spring_web2.Repository.CutomerRepository;

@Service
public class CustomerService {

	@Autowired
	private CutomerRepository cus;
	
	public List<Customer> getAll(){
		return cus.findAll();
		
	}
	
	public Customer saveCustomer(Customer customer){
		return cus.save(customer);
		
	}
	
   public String getDateTime() {
	   LocalDateTime dt2=LocalDateTime.of(2024,05, 12, 11, 15,55);
	   DateTimeFormatter dtformat= DateTimeFormatter.ofPattern("dd-mm-yyyy ||");
	   DateTimeFormatter isoLocalDate = dtformat.ISO_DATE_TIME;
	return dt2.format(isoLocalDate);
	   
   }
   public org.springframework.data.domain.Page<Customer> getPagationOffsetAndSize(int offset, int pagesize){
	return  cus.findAll(PageRequest.of(offset, pagesize));
	   
   }
   
   public List<Customer> searchCustomers(String searchText) {
		return cus.findBycnameContainingIgnoreCase(searchText);
	}

}
