import { HttpClientModule } from "@angular/common/http";
import { NgModule, Pipe } from "@angular/core";
import { FormsModule, NgModel, NgModelGroup, ReactiveFormsModule } from "@angular/forms";
import { BrowserModule, provideClientHydration } from "@angular/platform-browser";
import { AddProductItemComponent } from "./add-product-item/add-product-item.component";
import { AddProductComponent } from "./add-product/add-product.component";
import { ApiserviceService } from "./apiservice.service";
import { AppComponent } from "./app.component";
import { ListproductComponent } from "./listproduct/listproduct.component";
import { TableComponent } from "./table/table.component";
import { AppRoutingModule } from "./app-routing.module copy";
import { FilterPipe } from './filter.pipe';
import { MainComponent } from './main/main.component';



@NgModule({
  declarations: [
    AppComponent,
    AddProductComponent,
    TableComponent,
    ListproductComponent,
    AddProductItemComponent,
    FilterPipe,
    MainComponent,
   

  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    AppRoutingModule,
    FormsModule,
    
  ],
  providers: [
    provideClientHydration(),
    ApiserviceService
  ],
  bootstrap: [AppComponent]
})
export class AppModule {
}