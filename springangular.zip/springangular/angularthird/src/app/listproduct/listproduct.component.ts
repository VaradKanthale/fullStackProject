import { Component, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { take } from 'rxjs';
import { Product } from '../Model/Product';

@Component({
  selector: 'app-listproduct',
  templateUrl: './listproduct.component.html',
  styleUrl: './listproduct.component.css'
})
export class ListproductComponent implements OnInit{
  allCustomerProduct: Array<Product> = [];
  constructor(
    private service: ApiserviceService
  ) {

  }
  
  ngOnInit(): void {
    this.getProduct();
   
  }
  getProduct(){
  this.service.getAllProduct().pipe(take(1)).subscribe((res:any) =>{
    if (res && Array.isArray(res)) {
      console.log('####', res);
      this.allCustomerProduct = res;
    }
  });
}

  deleteProduct(Product:any):void{

    this.service.deleteProductByPid(Product?.pid).subscribe((res:any)=>{
      
        console.log(">>>>>>>>>>>",res);
        alert('Product Deleted sucessfully');
        this.getProduct();
    })

  }
 
}
