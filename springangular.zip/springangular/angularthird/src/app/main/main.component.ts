import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrl: './main.component.css'
})
export class MainComponent {
  Fun:any= 'Fuction perform';

  errorMessage: String = ' ';
  errorMessage2: String = ' ';
  errorMessage3: String = ' ';
  email:any=' ';
  password:any=' ';

  regex: any =
  /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  reg: any = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?!.* ).{5,8}$/;

  constructor(private router:Router){

  }

  Submit():void{
    if(this.Fun === 'User'   ){
      alert('User Login');

      if (!this.regex.test(this.email)) {
        alert('email is Not Correct Format');
        this.errorMessage = 'email is Not Correct Format';
         return;
       } else if (!this.reg.test(this.password)) {
        alert('password is Not Correct Format');
        this.errorMessage2 =
         'password must contain a single digit from 1 to 9 and one lowercase letter and one uppercase letter and one special character and must be 5-8 characters long';
          return;
      }else{
        alert('Submit Liogin');
        this.router.navigate(['/addproduct'])
        
      }
      }else if(this.Fun === 'Admin'){
        alert('Admin Login');

        if (!this.regex.test(this.email)) {
          alert('email is Not Correct Format');
          this.errorMessage = 'email is Not Correct Format';
           return;
         } else if (!this.reg.test(this.password)) {
          alert('password is Not Correct Format');
          this.errorMessage2 =
           'password must contain a single digit from 1 to 9 and one lowercase letter and one uppercase letter and one special character and must be 5-8 characters long';
            return;
        }else{
          alert('Submit Liogin');
          
          this.router.navigate(['/add-produt-item'])

        }
      }else if (!(this.Fun === ('User' || 'Admin'))) {
        alert('Please Select Your Option User or Admin')
        this.errorMessage3='Please Select Your Option User or Admin';
      }
      
    }
   
}
