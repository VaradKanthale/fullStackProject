export class Product{
    pid!: number
    pname!: string
    pPrice!: number
    status!: boolean


}