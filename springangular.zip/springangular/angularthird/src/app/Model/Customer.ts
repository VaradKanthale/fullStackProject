import { Product } from "./Product"

export class Customer {
    cid!: number 
    cname!: string 
    password!: string 
    email!: any 
    city!: string 
    status!: boolean 
    dd!:any
    time!:any
    productList!: Array<Product>

    
}