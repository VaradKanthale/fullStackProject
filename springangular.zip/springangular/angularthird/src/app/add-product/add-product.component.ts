import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiserviceService } from '../apiservice.service';
import { take } from 'rxjs';
import { Console } from 'console';
import { Customer } from '../Model/Customer';

@Component({
  selector: 'app-add-product',
  templateUrl: './add-product.component.html',
  styleUrl: './add-product.component.css',
})
export class AddProductComponent {
 
  
  Name: String = ' ';
  Password: any = ' ';
  email: any =' ';
  city: string=' ';
  dd:any=' ';
  status: boolean=false;
  time:any=' ';

  password2: any = ' ';
  errorMessage: String = ' ';
  errorMessage2: String = ' ';
  errorMessage3: String = ' ';
  errorMessage4: String = ' ';
  errorMessage5: String = ' ';
  errorMessage6: String = ' ';

   regex: any =
     /^(([^<>()[\]\\.,;:\s@"]+(\.[^<>()[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
     reg: any = /^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?!.* ).{5,8}$/;

  constructor(private router: Router,
    private service: ApiserviceService
  ) {}

  addupdate(): void {
     if (this.Name === ' ') {
       alert('Name is Required');
       this.errorMessage = 'Name is Required';
      return;
     }else if (!this.reg.test(this.Password)) {
      alert('password is Not Correct Format');
      this.errorMessage2 =
       'password must contain a single digit from 1 to 9 and one lowercase letter and one uppercase letter and one special character and must be 5-8 characters long';
        return;
    }
      else if (!this.regex.test(this.email)) {
      alert('email is Not Correct Format');
      this.errorMessage3 = 'email is Not Correct Format';
       return;
     } 
    
     else if (this.city === ' ') {
      alert('City is Required');
      this.errorMessage4 = 'City is Required';
    //  this.router.navigate(['/table']);
     return;
     }
   /* else if (this.dd === ' ') {
      alert('Date is Required');
      this.errorMessage5 = 'Date is Required';
    //  this.router.navigate(['/table']);
     return;
     } */

     else if (this.status === null ) {
      alert('Status is Required');
      this.errorMessage6 = 'Status is Required';
     return; 
     }

    const body: any = {
      cname: this.Name,
      password: this.Password,
      email: this.email,
     city: this.city,
     status: this.status
    };
    console.log('>>>>>>>>', body);
    this.service.addUser(body).pipe(take(1)).subscribe((res: any) => {
      console.log('>>>>>>>>',body);
        alert("Customer added successfully");
        this.router.navigate(['/table']);
      
     });
    
     }
    }
  

