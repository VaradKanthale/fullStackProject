import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AddProductComponent } from './add-product/add-product.component';
import { TableComponent } from './table/table.component';
import { ListproductComponent } from './listproduct/listproduct.component';
import { AddProductItemComponent } from './add-product-item/add-product-item.component';
import { MainComponent } from './main/main.component';

const routes: Routes = [
  {path:'addproduct', component:AddProductComponent},
  {path:'table',component:TableComponent},
  {path: 'products', component: ListproductComponent},
  {path: 'add-produt-item', component: AddProductItemComponent},
  {path: 'main', component: MainComponent}

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
