import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { ApiserviceService } from './apiservice.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css'
})
export class AppComponent {
  title = 'angularthird';
 
  constructor(private router:Router , private service:ApiserviceService){
    
  }

  oneTo(s:any):void{
    this.router.navigate(['/'+s])
  }
 

 
}
