import { Component, Input, OnDestroy, OnInit } from '@angular/core';
import { ApiserviceService } from '../apiservice.service';
import { Subject, debounceTime, take } from 'rxjs';
import { Router } from '@angular/router';
import { Customer } from '../Model/Customer';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrl: './table.component.css'
})
export class TableComponent implements OnInit , OnDestroy{
  //allCustomer: Array<Customer>=[];
  searchText: string = '';
  customers: Customer[] = [];
  @Input() message: string = '';
  
  searchString = new Subject<string>();
 
  constructor(private service:ApiserviceService , private router:Router){
  }
  ngOnInit(): void {
    this.getAll();
    this.searchString.pipe(debounceTime(500)).subscribe((value: string) => {
      this.searchUsers(value);
    });
  }

  onSearchInput(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    const value = inputElement.value;
    this.searchString.next(value);
    // this.searchUsers(value);
  }

  searchUsers(searchText: string) {
    this.service.searchCustomers(searchText).subscribe(
   (data: Customer[]) => {
     if (data.length > 0) {
      console.log('******',data.length);

       const adminId = localStorage.getItem('cname');
       console.log('******',adminId);
       this.customers = data;

       /* if (adminId !== null) {
        this.customers = data.filter((item: any) => item?.cid !== parseInt(adminId, 10));
      } else  {
        this.customers = data;
       } */
     } else {
       this.customers = [];
     }
   },
   (error: any) => {
     console.error('Error searching customers', error);
   }
 );
}



  getAll():void{
    this.service.getAllCustomer().pipe(take(1)).subscribe((res:any) =>{
      this.customers=res;

    } )
  }

  deleteCustomer(Customer:any):void{

    this.service.deleteCustomerByCid(Customer?.cid).subscribe( (res:any)=>{
      console.log(">>>>>>>>>>>>>>",res);
      alert('Customer Deleted SucessFully');
      this.getAll();
    })

  }
 
ngOnDestroy(): void {
  this.searchString.unsubscribe();
}

  }

